package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class HomePage {
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(how=How.XPATH, using="//*[@aria-label='Search and explore']") WebElement searchButton;
	@FindBy(how=How.XPATH, using="//input[@aria-label='Search query'][@data-testid='SearchBox_Search_Input']") WebElement searchBar;
	@FindBy(how=How.XPATH, using="//div[@id='typeaheadDropdown-11']") WebElement dropDownSearch;
	
	@FindBy(how=How.XPATH, using="//div/h2[@role='heading']//div/div/div/span[1]/span/span") WebElement pageHeader;
	
	public WebElement getSearchButton() {
		return searchButton;
	}
	public WebElement getSearchBar() {
		return searchBar;
	}
	public WebElement getDropDownSearch() {
		return dropDownSearch;
	}
	public WebElement getPageHeader() {
		return pageHeader;
	}
}