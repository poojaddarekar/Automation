package stepDefinations;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.HomePage;
import pages.LoginPage;
import pages.TwitterProfilePage;
import tests.TestBase;
import tests.ConnectTwitter;

public class stepDefination extends TestBase {
	
	
	HomePage homePage = PageFactory.initElements(driver, HomePage.class);
	TwitterProfilePage profilePage = PageFactory.initElements(driver, TwitterProfilePage.class);
	
	@Given("^User launches Twitter Sign In page$")
	public void User_launches_Twitter_Sign_In_page() throws Exception {
		driver=initializeDriver();
		driver.get("https://twitter.com/login");
	}
	
	@When("^User logs into Twitter using available username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void user_logs_into_twitter_using_available_username_as_something_and_password_as_something(String strArg1, String strArg2) throws Throwable {
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		
		//WebDriverWait wait = new WebDriverWait(driver, 50);
		//wait.until(ExpectedConditions.visibilityOf(loginPage.getLogin())); 
		//wait.until(ExpectedConditions.elementToBeClickable(loginPage.getLogin()));
		
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", loginPage.getUser());
				loginPage.getUser().sendKeys(strArg1);
				
		loginPage.getPsw().sendKeys(strArg2);
			
		loginPage.getLogin().click();
	}
	
	@Then("^Login is successful$")
	public void Login_is_successful() throws Exception {
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		if (loginPage.getHomePageName().getText().equals("Home")) {
			System.out.println("Login Successful!");
		} else {
			System.out.println("Login Failed!");
		}
	}
	
	@And("^User logs out$")
	public void User_logs_out() throws Exception {
		LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		loginPage.getAccNavButton().click();
		Thread.sleep(2000);
		loginPage.getLogoutButton().click();
		
		loginPage.getLogoutConf().click();	
	}
	
   
    
    @Then("^Error message is shown for invalid login$")
    public void error_message_is_shown_for_invalid_login(String errorMessage) throws Throwable {
    	LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
    	String actualErrMsg = loginPage.getErrMsg().getText(); 
    	if (actualErrMsg.equals(errorMessage)) {
    		System.out.println("InvalidLoginTest : Passed!");
    		Assert.assertEquals(errorMessage, actualErrMsg);
    	}
    }

    @And("^User set profile details bio as \"([^\"]*)\" and location as \"([^\"]*)\" and url as \"([^\"]*)\"$")
    public void user_set_profile_details_bio_as_something_and_location_as_something_and_url_as_something(String strArg1, String strArg2, String strArg3) throws Throwable {
    	TwitterProfilePage profilePage = PageFactory.initElements(driver, TwitterProfilePage.class);	
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
    	profilePage.getProfileButton().click();
    	profilePage.getEditProfileButton().click();
    			
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	profilePage.getBioText().clear();	
    	profilePage.getBioText().sendKeys(strArg1);
    	
    	profilePage.getLocationText().clear();
    	profilePage.getLocationText().sendKeys(strArg2);
    	
    	profilePage.getUrlText().clear();
    	profilePage.getUrlText().sendKeys(strArg3);
    	
    	profilePage.getSaveButton().click();
    }

    @And("^User verifies profile details as \"([^\"]*)\" and location as \"([^\"]*)\" and url as \"([^\"]*)\"$")
    public void user_verifies_profile_details_as_something_and_location_as_something_and_url_as_something(String strArg1, String strArg2, String strArg3) throws Throwable {
    	TwitterProfilePage profilePage = PageFactory.initElements(driver, TwitterProfilePage.class);
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
    	if(profilePage.getActualBioText().getText().equals(strArg1)){
			System.out.println("Bio text updated to : "+ strArg1); 	}
		else { 
			System.out.print("|"+profilePage.getActualBioText().getText()+"|");
			throw new Exception("Error : Bio text not updated!");	}
		
		if(profilePage.getActualLocationText().getText().equals(strArg2)){
			System.out.println("Location updated to : "+ strArg2); 	}
		else { 
			System.out.print("|"+profilePage.getActualLocationText().getText()+"|");
			throw new Exception("Error : Location not updated!");
		}
		
		if(profilePage.getActualURLText().getText().equals(strArg3)){
			System.out.println("URL updated to : "+ strArg3);	}  
		else { 
			System.out.print("|"+profilePage.getActualURLText().getText()+"|");
			throw new Exception("Error : URL not updated!");
		}
	}

    private boolean equals(String text, String strArg1) {
		// TODO Auto-generated method stub
		return false;
	}

	@And("^User selects profile picture as \"([^\"]*)\" and set the picture$")
    public void user_selects_profile_picture_as_something_and_set_the_picture(String strArg1) throws Throwable {
    	TwitterProfilePage profilePage = PageFactory.initElements(driver, TwitterProfilePage.class);
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
    	profilePage.getProfileButton().click();
    	profilePage.getEditProfileButton().click();
		
    	profilePage.getProfilePicButton().click();
		driver.switchTo()
				.activeElement()
				.sendKeys(strArg1);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		driver.switchTo().activeElement();
		profilePage.getProfilePicApplyButton().click();
		profilePage.getSaveButton().click();
    }
    
    @And("^User searches for tweets using search string as \"([^\"]*)\"$")
    public void user_searches_for_tweets_using_search_string_as_something(String strArg1) throws Throwable {
          
		HomePage homePage = PageFactory.initElements(driver, HomePage.class);
		
		homePage.getSearchButton().click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		homePage.getSearchBar().sendKeys(strArg1);
		homePage.getSearchBar().sendKeys(Keys.ENTER);
		
		Select dropDownList = new Select(homePage.getDropDownSearch());
		dropDownList.selectByVisibleText(strArg1);
		
		Assert.assertEquals(strArg1, homePage.getPageHeader().getText());
    }

 	@And("^User closes browser$")
	public void user_closes_browser() throws Throwable {
		closeDriver();
	}
    
 	 @Given("^User creates Twitter instance$")
     public void user_creates_twitter_instance() throws Throwable {
 		ConnectTwitter connectTwitter = new ConnectTwitter();
 		connectTwitter.getTwitterinstance();
        throw new PendingException();
     }

     @When("^User searches for tweets$")
     public void user_searches_for_tweets() throws Throwable {
    	 ConnectTwitter.searchtweets("Query string");
         throw new PendingException();
     }

     @Then("^User creates and verifies tweets$")
     public void user_creates_and_verifies_tweets() throws Throwable {
    	 //Code to verify newly created tweets
         throw new PendingException();
     }
}
