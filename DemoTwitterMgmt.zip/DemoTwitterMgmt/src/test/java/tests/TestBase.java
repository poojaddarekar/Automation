package tests;

import java.io.IOException;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {
	public WebDriver driver;
	
	public WebDriver initializeDriver() throws IOException {
		//Initialized for Chrome driver only
		System.setProperty("webdriver.chrome.driver", "Chrome_Driver_Location");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
		return driver;
	}
	
	public void closeDriver() {
		driver.close();
		driver.quit();
		driver = null;
	}
}